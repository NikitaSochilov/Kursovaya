var searchData=
[
  ['parse_5farguments_0',['parse_arguments',['../classUserInterface.html#a5899f0f23f1f117457162bab9e6332a4',1,'UserInterface']]],
  ['port_5fnumber_1',['port_number',['../structConfiguration.html#a540b3f276afa66ad164fe95d444aed8e',1,'Configuration']]]
];
