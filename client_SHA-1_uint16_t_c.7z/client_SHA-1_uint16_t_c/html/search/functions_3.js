var searchData=
[
  ['parse_5farguments_0',['parse_arguments',['../classUserInterface.html#a5899f0f23f1f117457162bab9e6332a4',1,'UserInterface']]]
];
