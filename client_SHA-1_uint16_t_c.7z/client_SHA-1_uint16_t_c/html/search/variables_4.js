var searchData=
[
  ['server_5faddress_0',['server_address',['../structConfiguration.html#abe5ec8baa2aa83742972bccbb5ebdee4',1,'Configuration']]]
];
