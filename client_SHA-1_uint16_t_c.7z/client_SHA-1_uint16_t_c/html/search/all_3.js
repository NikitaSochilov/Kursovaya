var searchData=
[
  ['generate_5fhash_0',['generate_hash',['../crypto_8cpp.html#a1a54adc1b3082f44d723a064b010f162',1,'generate_hash(string salt_value, string password_value):&#160;crypto.cpp'],['../crypto_8h.html#a1a54adc1b3082f44d723a064b010f162',1,'generate_hash(string salt_value, string password_value):&#160;crypto.cpp']]],
  ['get_5fconfiguration_1',['get_configuration',['../classUserInterface.html#a61acf33dbbfded3017937147fc011a6c',1,'UserInterface']]],
  ['get_5fhelp_5ftext_2',['get_help_text',['../classUserInterface.html#a7cd5deeb2a1007f6d0af38454c0d5f8c',1,'UserInterface']]]
];
