var searchData=
[
  ['userinterface_0',['userinterface',['../classUserInterface.html',1,'UserInterface'],['../classUserInterface.html#ae6fb70370701b3bd6120e923df9705b0',1,'UserInterface::UserInterface()']]]
];
